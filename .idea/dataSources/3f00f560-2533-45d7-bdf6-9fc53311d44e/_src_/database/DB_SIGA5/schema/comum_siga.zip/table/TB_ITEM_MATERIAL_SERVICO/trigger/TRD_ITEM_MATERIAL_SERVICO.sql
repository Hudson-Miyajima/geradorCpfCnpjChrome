
CREATE TRIGGER [comum_siga].[TRD_ITEM_MATERIAL_SERVICO]
  ON [comum_siga].[TB_ITEM_MATERIAL_SERVICO]
  AFTER DELETE
  AS
    -- Realiza a remocao do item na base do Compras a partir 
    -- do item material/servico.

    SET XACT_ABORT OFF
    SET NOCOUNT ON

    DECLARE @IMS_ID INT,
    @MS_ID INT,
    @IC_ID INT,
    @MENS VARCHAR(100),
    @IMS_STATUS VARCHAR(20),
    @INTEGRAR CHAR(1);
    
    BEGIN TRY
        IF (catalogo.FN_INTEGRACAO_ATIVA()) = 'N' RETURN
    END TRY
    BEGIN CATCH
        RAISERROR('Parâmetro de ativação da integração não encontrado.',16,1,null,'NOWAIT')
        RETURN
    END CATCH

    SELECT @IMS_ID = IMS_ID,
    @MS_ID = MS_ID,
    @IMS_STATUS = IMS_STATUS
    FROM DELETED;

    IF @IMS_STATUS != 'APROVADO' RETURN

    BEGIN TRY
        BEGIN TRANSACTION
            -- Tenta remover as relações do item com a classe
            DELETE FROM catalogo.SY_ITEMCOMPRA_CLASSE 
            WHERE IC_ID IN (SELECT IC_ID FROM catalogo.SY_ITEM_COMPRA WHERE IMS_ID = @IMS_ID);

            -- Tenta remover o(s) item(ns) no Compras
            DELETE FROM catalogo.SY_ITEM_COMPRA WHERE IMS_ID = @IMS_ID;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION

        SET @MENS = CONCAT('Não foi possivel excluir o item no Compras: ', CAST(@IMS_ID AS VARCHAR))

        BEGIN TRY
            -- Caso nao consiga, inativa
            UPDATE catalogo.SY_ITEM_COMPRA
            SET IC_SITUACAO = 'Inativo'
            WHERE IMS_ID = @IMS_ID;
        END TRY
        BEGIN CATCH
            SET @MENS = CONCAT('Não foi possivel atualizar o item no Compras: ', CAST(@IMS_ID AS VARCHAR))
            RAISERROR(@MENS,16,2,null,'NOWAIT')
        END CATCH
    END CATCH

    IF @@TRANCOUNT > 0 COMMIT TRANSACTION
GO
