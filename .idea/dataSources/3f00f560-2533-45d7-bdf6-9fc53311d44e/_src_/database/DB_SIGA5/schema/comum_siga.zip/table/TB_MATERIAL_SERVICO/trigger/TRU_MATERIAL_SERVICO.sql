
-- Create triggers for table comum_siga.TB_MATERIAL_SERVICO

CREATE TRIGGER [comum_siga].[TRU_MATERIAL_SERVICO]
  ON [comum_siga].[TB_MATERIAL_SERVICO]
  AFTER UPDATE
  AS
    -- Realiza a inclusão ou alteração do produto na base do Compras a partir 
    -- do material/servico.

    SET XACT_ABORT OFF
    SET NOCOUNT ON

    DECLARE @MS_SITUACAO VARCHAR(10),
    @MS_SITUACAO_ANT VARCHAR(10),
    @MS_CODIGO VARCHAR(10),
    @MS_DESCRICAO VARCHAR(120),
    @MS_ID INT,
    @MS_TIPO VARCHAR(10),
    @SITUACAO VARCHAR(10),
    @CL_ID INT,
    @MS_STATUS VARCHAR(20),
    @MS_STATUS_ANT VARCHAR(20),
    @ATUALIZA_INSERE CHAR(1),
    @MENS VARCHAR(200),
    @INTEGRAR CHAR(1);

    BEGIN TRY
        IF (catalogo.FN_INTEGRACAO_ATIVA()) = 'N' RETURN
    END TRY
    BEGIN CATCH
        RAISERROR('Parâmetro de ativação da integração não encontrado.',16,5,null,'NOWAIT')
        RETURN
    END CATCH

    SET @SITUACAO = 'ATIVO';
    SET @ATUALIZA_INSERE = 'N';

    -- Captura dados atuais
    SELECT @MS_SITUACAO = MS_SITUACAO,
    @MS_STATUS = MS_STATUS,
    @MS_CODIGO = MS_CODIGO,
    @MS_DESCRICAO = MS_DESCRICAO,
    @MS_ID = MS_ID,
    @MS_TIPO = MS_TIPO
    FROM INSERTED;

    -- Captura dados anteriores
    SELECT @MS_SITUACAO_ANT = MS_SITUACAO,
    @MS_STATUS_ANT = MS_STATUS
    FROM DELETED;

    -- Material/Servico aprovado com situacao alterada para ativa
    IF (@MS_SITUACAO != @MS_SITUACAO_ANT AND @MS_SITUACAO = 'ATIVO' 
        AND @MS_STATUS = 'APROVADO') BEGIN
        SET @ATUALIZA_INSERE = 'S';
    END

    -- Material/Servico ativo com status alterado para aprovado
    IF (@MS_STATUS != @MS_STATUS_ANT AND  @MS_STATUS = 'APROVADO' 
        AND @MS_SITUACAO = 'ATIVO') BEGIN
        SET @ATUALIZA_INSERE = 'S';
    END

    -- Insere ou atualiza como produto no Compras.
    IF (@ATUALIZA_INSERE = 'S') BEGIN

        -- Verifica se o produto ja existe
        IF EXISTS(SELECT PR_ID FROM catalogo.SY_PRODUTO WHERE MS_ID = @MS_ID) BEGIN
            BEGIN TRY
                -- Se existir, atualiza e reativa
                UPDATE catalogo.SY_PRODUTO
                SET PR_DESC = @MS_DESCRICAO,
                PR_SITUACAO = 'Ativo'
                WHERE MS_ID = @MS_ID
            END TRY
            BEGIN CATCH
                SET @MENS = CONCAT('Não foi possivel atualizar o produto no Compras: ', CAST(@MS_ID AS VARCHAR))
                RAISERROR(@MENS,16,1,null,'NOWAIT')
                RETURN
            END CATCH
        END 
        ELSE BEGIN
            -- Se nao existir, insere novo
        
            -- Busca o ID da classe item no legado a partir do
            -- codigo do subelemento do catalogo. Retorna apenas um.
            SET @CL_ID = catalogo.FN_CLASSE_LEGADO(@MS_ID);

            IF (@CL_ID IS NULL) BEGIN
                SET @MENS = CONCAT('Não foi possivel identificar a classe no Compras para o Material/Serviço: ', CAST(@MS_ID AS VARCHAR))
                RAISERROR(@MENS,16,4,null,'NOWAIT')
                RETURN
            END
        
            BEGIN TRY
                INSERT INTO catalogo.SY_PRODUTO (PR_DESC, PR_TIPO, CL_ID, PR_SITUACAO, 
                PR_CODIGO, MS_ID)
                VALUES (@MS_DESCRICAO, SUBSTRING(@MS_TIPO,1,1), @CL_ID, 'Ativo',
                @MS_CODIGO, @MS_ID);
            END TRY
            BEGIN CATCH
                SET @MENS = CONCAT('Não foi possivel inserir o produto no Compras: ', CAST(@MS_ID AS VARCHAR))
                RAISERROR(@MENS,16,2,null,'NOWAIT')
                RETURN
            END CATCH        
        END   
    END

    -- Material/Servico desativado. Desativa como produto no Compras.
    IF (@MS_SITUACAO_ANT = 'ATIVO' AND  @MS_SITUACAO != 'ATIVO') BEGIN
        BEGIN TRY
            UPDATE catalogo.SY_PRODUTO
            SET PR_SITUACAO = 'Inativo'
            WHERE MS_ID = @MS_ID
        END TRY
        BEGIN CATCH
            SET @MENS = CONCAT('Não foi possivel inativar o produto no Compras: ', CAST(@MS_ID AS VARCHAR))
            RAISERROR(@MENS,16,3,null,'NOWAIT')
            RETURN
        END CATCH    
    END
GO
