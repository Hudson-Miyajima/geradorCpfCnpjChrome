
CREATE TRIGGER [comum_siga].[TRD_MATERIAL_SERVICO]
  ON [comum_siga].[TB_MATERIAL_SERVICO]
  AFTER DELETE
  AS
    -- Realiza a remocao ou inativacao do produto na base do Compras
    -- quando o material/servico eh removido.

    SET NOCOUNT ON;

    DECLARE @MS_ID INT,
    @MENS VARCHAR(200);

    BEGIN TRY
        IF (catalogo.FN_INTEGRACAO_ATIVA()) = 'N' RETURN
    END TRY
    BEGIN CATCH
        RAISERROR('Parâmetro de ativação da integração não encontrado.',16,1,null,'NOWAIT')
        RETURN
    END CATCH

    SELECT @MS_ID = MS_ID
    FROM DELETED;

    -- Tenta remover o produto
    BEGIN TRY
        DELETE FROM catalogo.SY_PRODUTO WHERE MS_ID = @MS_ID
    END TRY

    -- Caso nao consiga, inativa
    BEGIN CATCH
        UPDATE catalogo.SY_PRODUTO
        SET PR_SITUACAO = 'Inativo'
        WHERE MS_ID = @MS_ID;

        SET @MENS = CONCAT('Não foi possivel excluir o produto no Compras: ', CAST(@MS_ID AS VARCHAR))
        RAISERROR(@MENS,16,1,null,'NOWAIT')
    END CATCH
GO
