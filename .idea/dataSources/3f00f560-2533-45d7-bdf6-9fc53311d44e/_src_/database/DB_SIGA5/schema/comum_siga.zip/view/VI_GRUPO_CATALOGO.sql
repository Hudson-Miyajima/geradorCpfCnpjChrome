
CREATE VIEW [comum_siga].[VI_GRUPO_CATALOGO]
AS 
SELECT G.GR_CODIGO, G.GR_DESCRICAO, G.GR_TIPO
FROM comum_siga.TB_GRUPO G
GO
DECLARE @sn NVARCHAR(30)
SET @sn = schema_name()
EXECUTE sp_addextendedproperty N'MS_Description', N'Visão do grupo. Criada para au', N'SCHEMA', @sn, N'VIEW',
                               N'VI_GRUPO_CATALOGO'
GO
