
CREATE TRIGGER [comum_siga].[TRI_MATSER_UNIDAQUIS]
  ON [comum_siga].[TB_MATSER_UNIDAQUIS]
  AFTER INSERT
  AS

    -- Após a inclusão da nova unidade de aquisição para o material/serviço (Ativo e Aprovado)
    -- Identifica os itens (Ativos e Aprovados) e insere no Compras com a nova unidade.

    SET XACT_ABORT OFF
    SET NOCOUNT ON

    DECLARE @MS_SITUACAO VARCHAR(10),
    @MS_STATUS VARCHAR(20),
    @MS_ID INT,
    @UA_ID INT,
    @MENS VARCHAR(200),
    @UN_ID VARCHAR(30),
    @PR_ID INT,
    @IMS_ID INT,
    @IMS_DESCRICAO VARCHAR(MAX),
    @IMS_DESCRICAO_TRUNCADA VARCHAR(150),
    @IMS_CODIGO VARCHAR(20),
    @IMS_TIPO VARCHAR(15),
    @USUARIO VARCHAR(20),
    @IC_ID INT;

    BEGIN TRY
        IF (catalogo.FN_INTEGRACAO_ATIVA()) = 'N' RETURN
    END TRY
    BEGIN CATCH
        RAISERROR('Parâmetro de ativação da integração não encontrado.',16,1,null,'NOWAIT')
        RETURN
    END CATCH

    SELECT @MS_ID = MS_ID,
    @UA_ID = UA_ID
    FROM INSERTED;

    SELECT @MS_SITUACAO = MS_SITUACAO, 
    @MS_STATUS = MS_STATUS
    FROM comum_siga.TB_MATERIAL_SERVICO
    WHERE MS_ID = @MS_ID;

	SELECT @IMS_TIPO = UA_TIPO FROM comum_siga.TB_UNIDADE_AQUISICAO WHERE UA_ID = @UA_ID

    IF (@MS_SITUACAO != 'ATIVO' OR @MS_STATUS != 'APROVADO') BEGIN
        RETURN
    END

    -- Recupera ID do produto cadastrado no Compras
    BEGIN TRY
        SET @PR_ID = catalogo.FN_PRODUTO_LEGADO(@MS_ID);

        IF (@PR_ID IS NULL) BEGIN
            SET @MENS = CONCAT('Produto não encontrado no Compras pelo ID do material/serviço: ', CAST(@MS_ID AS VARCHAR))
            RAISERROR(@MENS,16,1,null,'NOWAIT')
            RETURN
        END
    END TRY
    BEGIN CATCH
        SET @MENS = CONCAT('Produto não encontrado no Compras pelo ID do material/serviço: ', CAST(@MS_ID AS VARCHAR))
        RAISERROR(@MENS,16,1,null,'NOWAIT')
        RETURN
    END CATCH

    -- Verifica se a unidade esta ativa.
    --
    IF NOT EXISTS(SELECT UA_ID FROM comum_siga.TB_UNIDADE_AQUISICAO 
        WHERE UA_ID = @UA_ID AND UA_SITUACAO = 'ATIVO') BEGIN
        SET @MENS = CONCAT('Unidade de Aquisição inativa: ', CAST(@UA_ID AS VARCHAR))
        RETURN
    END

    -- Verifica existencia da unidade de aquisicao como
    -- unidade de medida no Compras. Caso nao exista, insere.
    BEGIN TRY
        EXEC catalogo.SP_INC_UNIDADE_LEGADO @IMS_TIPO, @UA_ID, @UN_ID = @UN_ID OUTPUT
    END TRY
    BEGIN CATCH
        SET @MENS = CONCAT('Não foi possivel inserir nova unidade no Compras: ', ERROR_MESSAGE())
		RAISERROR(@MENS,16,1,null,'NOWAIT')
        RETURN
    END CATCH

    SET @USUARIO = 'Integração'

    DECLARE U_ITENS CURSOR FOR
    SELECT IMS_ID,
    IMS_CODIGO,
    IMS_TIPO,
    CONCAT(IMS_DESCRICAO, IMS_DESCRICAO_COMPL),
    IMS_DESCRICAO_TRUNCADA
    FROM comum_siga.TB_ITEM_MATERIAL_SERVICO
    WHERE MS_ID = @MS_ID
    AND IMS_SITUACAO = 'ATIVO'
    AND IMS_STATUS = 'APROVADO'
    
    OPEN U_ITENS
    FETCH NEXT FROM U_ITENS INTO @IMS_ID,
        @IMS_CODIGO,
        @IMS_TIPO,
        @IMS_DESCRICAO,
        @IMS_DESCRICAO_TRUNCADA

    WHILE @@FETCH_STATUS = 0 BEGIN
        
		BEGIN TRY
            -- Verifica existencia da unidade de aquisicao como
            -- unidade de medida no Compras. Caso nao exista, insere.
            EXEC catalogo.SP_INC_UNIDADE_LEGADO @IMS_TIPO, @UA_ID, @UN_ID = @UN_ID OUTPUT
		END TRY
        BEGIN CATCH
            CLOSE U_ITENS   
            DEALLOCATE U_ITENS

            SET @MENS = CONCAT('Não foi possivel inserir a nova unidade no Compras: ', CAST(@UA_ID AS VARCHAR))
            RAISERROR(@MENS,16,1,null,'NOWAIT')
            RETURN
        END CATCH
		
        BEGIN TRY
            -- Insere novo item no Compras
            INSERT INTO catalogo.SY_ITEM_COMPRA(IC_CODIGO,IC_DESC_COMPLETA,
            IC_TIPO,UN_ID,PR_ID,IC_SITUACAO,IC_DT_CADASTRO,IC_USUARIO_CADASTRO,
            IC_DESC,IMS_ID,IC_ID)
            VALUES(@IMS_CODIGO,@IMS_DESCRICAO,SUBSTRING(@IMS_TIPO,1,1),@UN_ID,
            @PR_ID,'Ativo',GETDATE(),@USUARIO,@IMS_DESCRICAO_TRUNCADA,@IMS_ID,
            NEXT VALUE FOR catalogo.SEQ_ITEM_COMPRA);
            
            -- Recupera ID do item inserido
            SET @IC_ID = catalogo.FN_ITEM_LEGADO(@IMS_ID,@UA_ID);
            
            -- Insere os subelementos para o item no Compras
            EXEC catalogo.SP_INC_CLASSE_ITEM_LEGADO @MS_ID, @IC_ID
        END TRY
        BEGIN CATCH
            CLOSE U_ITENS   
            DEALLOCATE U_ITENS

            SET @MENS = CONCAT('Não foi possivel inserir o novo item no Compras: ', CAST(@IC_ID AS VARCHAR))
            RAISERROR(@MENS,16,2,null,'NOWAIT')
            RETURN
        END CATCH

        -- Recupera proxima unidade de aquisicao
        FETCH NEXT FROM U_ITENS INTO @IMS_ID,
            @IMS_CODIGO,
            @IMS_TIPO,
            @IMS_DESCRICAO,
            @IMS_DESCRICAO_TRUNCADA
    END

    CLOSE U_ITENS   
    DEALLOCATE U_ITENS

GO
