

-- Create triggers for table comum_siga.TB_ITEM_MATERIAL_SERVICO
CREATE TRIGGER [comum_siga].[TRU_ITEM_MATERIAL_SERVICO]
  ON [comum_siga].[TB_ITEM_MATERIAL_SERVICO]
  AFTER UPDATE
  AS
-- Realiza a inclusão ou alteração do item na base do Compras a partir 
-- do item material/servico.

SET XACT_ABORT ON
SET NOCOUNT ON

DECLARE @IMS_SITUACAO VARCHAR(10),
@IMS_SITUACAO_ANT VARCHAR(10),
@IMS_ID INT,
@IMS_DESCRICAO VARCHAR(MAX),
@IMS_DESCRICAO_ANT VARCHAR(MAX),
@IMS_DESCRICAO_TRUNCADA VARCHAR(150),
@IMS_CODIGO VARCHAR(20),
@IMS_TIPO VARCHAR(15),
@UN_ID VARCHAR(30),
@UA_ID INT,
@MS_ID INT,
@PR_ID INT,
@USUARIO VARCHAR(20),
@IC_ID INT,
@IMS_STATUS VARCHAR(20),
@IMS_STATUS_ANT VARCHAR(20),
@ATUALIZA_INSERE CHAR(1),
@MENS VARCHAR(200);

BEGIN TRY
    IF (catalogo.FN_INTEGRACAO_ATIVA()) = 'N' RETURN
END TRY
BEGIN CATCH
    RAISERROR('Parâmetro de ativação da integração não encontrado.',16,1,null,'NOWAIT')
    RETURN
END CATCH

SET @USUARIO = 'Integração';
SET @ATUALIZA_INSERE = 'N';

SELECT @IMS_SITUACAO = IMS_SITUACAO,
@MS_ID = MS_ID,
@IMS_CODIGO = IMS_CODIGO,
@IMS_TIPO = IMS_TIPO,
@IMS_DESCRICAO = CONCAT(IMS_DESCRICAO, IMS_DESCRICAO_COMPL),
@IMS_DESCRICAO_TRUNCADA = IMS_DESCRICAO_TRUNCADA,
@IMS_ID = IMS_ID,
@IMS_STATUS = IMS_STATUS
FROM INSERTED;

SELECT @IMS_SITUACAO_ANT = IMS_SITUACAO,
@IMS_STATUS_ANT = IMS_STATUS,
@IMS_DESCRICAO_ANT = IMS_DESCRICAO
FROM DELETED;

-- Item Material/Servico aprovado com situacao alterada para ativa
IF (@IMS_SITUACAO != @IMS_SITUACAO_ANT AND @IMS_SITUACAO = 'ATIVO' 
    AND @IMS_STATUS = 'APROVADO') BEGIN
    SET @ATUALIZA_INSERE = 'S';
END

-- Item Material/Servico ativo com status alterado para aprovado
IF (@IMS_STATUS != @IMS_STATUS_ANT AND  @IMS_STATUS = 'APROVADO' 
    AND @IMS_SITUACAO = 'ATIVO') BEGIN
    SET @ATUALIZA_INSERE = 'S';
END


-- Item Material/Servico ativo com descricao alterada
IF (@IMS_DESCRICAO != @IMS_DESCRICAO_ANT AND  @IMS_STATUS = 'APROVADO' 
    AND @IMS_SITUACAO = 'ATIVO') BEGIN
    SET @ATUALIZA_INSERE = 'S';
END

-- Insere/atualiza como item no Compras.
IF (@ATUALIZA_INSERE = 'S') BEGIN

    -- Recupera ID do produto cadastrado no Compras
    SET @PR_ID = catalogo.FN_PRODUTO_LEGADO(@MS_ID);
    
    -- Cursor para resgatar as unidades de aquisicao que o
    -- item pode ter. O item eh verificado no Compras para 
    -- cada unidade.
    DECLARE U_CURSOR CURSOR FOR
    SELECT UA_ID
    FROM comum_siga.TB_MATSER_UNIDAQUIS
    WHERE MS_ID = @MS_ID
    
    OPEN U_CURSOR
    FETCH NEXT FROM U_CURSOR INTO @UA_ID
    
    WHILE @@FETCH_STATUS = 0 BEGIN
        SET @IC_ID = NULL;
        
        -- Recupera o ID do item no Compras
        SET @IC_ID = catalogo.FN_ITEM_LEGADO(@IMS_ID,@UA_ID);
        
        -- Caso exista
        IF (@IC_ID IS NOT NULL) BEGIN
            BEGIN TRY
                -- Atualiza e reativa
                UPDATE catalogo.SY_ITEM_COMPRA
                SET IC_DESC_COMPLETA = @IMS_DESCRICAO,
                IC_DESC = @IMS_DESCRICAO_TRUNCADA,
                IC_SITUACAO = 'Ativo'
                WHERE IC_ID = @IC_ID;
            END TRY
            BEGIN CATCH
                CLOSE U_CURSOR   
                DEALLOCATE U_CURSOR

                SET @MENS = CONCAT('Não foi possivel atualizar o item no Compras: ', CAST(@IC_ID AS VARCHAR))
                RAISERROR(@MENS,16,1,null,'NOWAIT')
                RETURN
            END CATCH
        END 
        ELSE BEGIN
            -- Senao, insere novo
        
            BEGIN TRY
                -- Verifica existencia da unidade de aquisicao como
                -- unidade de medida no Compras. Caso nao exista, insere.
                EXEC catalogo.SP_INC_UNIDADE_LEGADO @IMS_TIPO, @UA_ID, @UN_ID = @UN_ID OUTPUT
        
                -- Insere novo item no Compras
                INSERT INTO catalogo.SY_ITEM_COMPRA(IC_CODIGO,IC_DESC_COMPLETA,
                IC_TIPO,UN_ID,PR_ID,IC_SITUACAO,IC_DT_CADASTRO,IC_USUARIO_CADASTRO,
                IC_DESC,IMS_ID,IC_ID)
                VALUES(@IMS_CODIGO,@IMS_DESCRICAO,SUBSTRING(@IMS_TIPO,1,1),@UN_ID,
                @PR_ID,'Ativo',GETDATE(),@USUARIO,@IMS_DESCRICAO_TRUNCADA,@IMS_ID,
                NEXT VALUE FOR catalogo.SEQ_ITEM_COMPRA);
            
                -- Recupera ID do item inserido
                SET @IC_ID = catalogo.FN_ITEM_LEGADO(@IMS_ID,@UA_ID);
            
                -- Insere os subelementos para o item no Compras
                EXEC catalogo.SP_INC_CLASSE_ITEM_LEGADO @MS_ID, @IC_ID
            END TRY
            BEGIN CATCH
                CLOSE U_CURSOR   
                DEALLOCATE U_CURSOR

                SET @MENS = CONCAT('Não foi possivel inserir o novo item no Compras: ', CAST(@IC_ID AS VARCHAR))
                RAISERROR(@MENS,16,2,null,'NOWAIT')
                RETURN
            END CATCH        
        END  
        
        -- Recupera proxima unidade de aquisicao
        FETCH NEXT FROM U_CURSOR INTO @UA_ID;
    END
    
    CLOSE U_CURSOR   
    DEALLOCATE U_CURSOR
END 

-- Item Material/Servico desativado. Desativa como produto no Compras.
IF (@IMS_SITUACAO_ANT = 'ATIVO' AND @IMS_SITUACAO = 'INATIVO') BEGIN
    -- Cursor para resgatar as unidades de aquisicao que o
    -- item pode ter. O item eh verificado no Compras para 
    -- cada unidade.
    DECLARE X_CURSOR CURSOR FOR
    SELECT UA_ID
    FROM comum_siga.TB_MATSER_UNIDAQUIS
    WHERE MS_ID = @MS_ID
    
    OPEN X_CURSOR
    FETCH NEXT FROM X_CURSOR INTO @UA_ID
    
    WHILE @@FETCH_STATUS = 0 BEGIN
        SET @IC_ID = NULL;
        
        -- Recupera o ID do item no Compras
        SET @IC_ID = catalogo.FN_ITEM_LEGADO(@IMS_ID,@UA_ID);
        
        -- Caso exista
        IF (@IC_ID IS NOT NULL) BEGIN
            BEGIN TRY
                -- Desativa o item
                UPDATE catalogo.SY_ITEM_COMPRA
                SET IC_SITUACAO = 'Inativo'
                WHERE IC_ID = @IC_ID;
            END TRY
            BEGIN CATCH
                CLOSE X_CURSOR   
                DEALLOCATE X_CURSOR

                SET @MENS = CONCAT('Não foi possivel inativar o item no Compras: ', CAST(@IC_ID AS VARCHAR))
                RAISERROR(@MENS,16,3,null,'NOWAIT')
                RETURN
            END CATCH 
        END
        FETCH NEXT FROM X_CURSOR INTO @UA_ID 
    END
    CLOSE X_CURSOR   
    DEALLOCATE X_CURSOR
END
GO
