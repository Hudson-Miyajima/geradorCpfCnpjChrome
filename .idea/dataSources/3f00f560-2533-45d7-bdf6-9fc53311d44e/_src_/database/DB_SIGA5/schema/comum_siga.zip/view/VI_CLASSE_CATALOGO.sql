
CREATE VIEW [comum_siga].[VI_CLASSE_CATALOGO]
AS 
SELECT G.GR_CODIGO, G.GR_TIPO, 
C.CL_CODIGO, C.CL_DESCRICAO
FROM comum_siga.TB_GRUPO G
JOIN comum_siga.TB_CLASSE C ON C.GR_ID = G.GR_ID
GO
DECLARE @sn NVARCHAR(30)
SET @sn = schema_name()
EXECUTE sp_addextendedproperty N'MS_Description', N'Visão da classe. Criada para a', N'SCHEMA', @sn, N'VIEW',
                               N'VI_CLASSE_CATALOGO'
GO
