
CREATE VIEW [comum_siga].[VI_CLASSE_MATSERV]
AS 
SELECT c.cl_id,
         c.cl_codigo,
         c.cl_descricao,
         isnull(c.cl_codigo, '')
         +' '
         +isnull(c.cl_descricao, '') AS cod_descricao,
         c.cl_situacao,
         CASE
           WHEN g.gr_tipo = 'MATERIAL' THEN 1
           ELSE 0
         END              AS material,
         CASE
           WHEN g.gr_tipo = 'SERVICO' THEN 1
           ELSE 0
         END              AS servico
  FROM   comum_siga.TB_CLASSE c
         join comum_siga.TB_GRUPO g
           ON g.gr_id = c.gr_id
GO
DECLARE @sn NVARCHAR(30)
SET @sn = schema_name()
EXECUTE sp_addextendedproperty N'MS_Description', N'Visão de uso interno do módulo', N'SCHEMA', @sn, N'VIEW',
                               N'VI_CLASSE_MATSERV'
GO
