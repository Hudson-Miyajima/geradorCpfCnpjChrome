
CREATE PROCEDURE [comum_siga].[SP_MAX_NUMBER_MATSER]
            @id Bigint, @str VARCHAR(20), @CODIGO varchar(20) OUTPUT
            AS
            BEGIN

                SET @CODIGO = (SELECT MAX(MS_CODIGO)  FROM comum_siga.TB_MATERIAL_SERVICO WHERE
                (PATINDEX(CONCAT(@str,'[0-9]'), MS_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9]'), MS_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9]'), MS_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9]'), MS_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9][0-9]'), MS_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9][0-9][0-9]'), MS_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9][0-9][0-9][0-9]'), MS_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'), MS_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'), MS_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'), MS_CODIGO) = 1) AND
                cl_id = @id)
                RETURN @CODIGO;
            END
GO
