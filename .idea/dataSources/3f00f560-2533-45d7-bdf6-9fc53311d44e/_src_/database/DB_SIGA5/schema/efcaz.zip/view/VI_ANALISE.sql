CREATE VIEW efcaz.VI_ANALISE AS 
 SELECT row_number() OVER (ORDER BY ap.an_data_analise DESC) AS ROW_ID,
    ap.an_id AS ID,
    so.so_id AS SOLICITACAO_ID,
    pe.PE_ID,
	pe.PE_ID_ORIGEM,
    pe.pe_cpf_cnpj AS DOCUMENTO,
    pe.pe_nome_razaosocial AS NOME,
		CASE
            WHEN pc.pe_ano_cerca IS NOT NULL THEN cast(pc.pe_numero_cerca as varchar(100)) + '/' + cast(pc.pe_ano_cerca as varchar(100)) 
            ELSE cast(pc.pe_numero_cerca as varchar(100))
        END AS CERCA,
	cast( cast(pc.pe_ano_cerca as varchar(100)) + cast(right(replicate('0',10) + convert(VARCHAR,pc.pe_numero_cerca),10) as varchar(100)) as bigint ) AS CERCA_ORD ,  
    pe.pa_id AS PAIS_ID,
    ap.an_data_protocolo AS DATA_PROTOCOLO,
    so.so_tipo_solicitacao AS TIPO_SOLICITACAO,
    so.so_situacao AS SITUACAO_SOLICITACAO,
    ap.an_data_analise AS DATA_ANALISE,
    ap.an_data_publicacao AS DATA_PUBLICACAO,
    us.us_nome AS RESPONSAVEL,
    ap.an_resultado AS RESULTADO,
    ap.an_finalizada AS FINALIZADA
   FROM efcaz.tb_analise_pessoa ap
     JOIN comum.tb_usuario us ON ap.us_id = us.us_id
     JOIN efcaz.tb_solicitacao so ON ap.so_id = so.so_id
     JOIN efcaz_staging.tb_pessoa pe ON so.so_id = pe.so_id
     LEFT JOIN comum_siga.tb_pessoa pc ON pc.pe_id = pe.pe_id_origem
GO
