
-- Changeset efcaz/1.2/mssql/1.2.1-SNAPSHOT-1.xml::1.2.1-view-01::efcaz-db
CREATE view efcaz.vi_pessoas_membros_usuarios
AS
  SELECT ROW_NUMBER() OVER (ORDER BY origem, id_origem) as ID, * FROM
    (
      SELECT 'Comum.Usuario' AS origem,
             u.us_id         AS id_origem,
             u.us_nome       AS nome,
             CASE
             WHEN Len( u.us_doc_chave ) = 11 THEN 0
             ELSE 1
             end             pessoa_juridica,
             u.us_doc_chave  AS documento,
             ''              AS rg,
             ''              AS rg_emissor,
             u.us_telefone   AS telefone,
             u.us_email      AS email,
             u.pa_id         AS pais_id
      FROM   comum.TB_USUARIO u
      UNION
      SELECT 'ComumSiga.Pessoa'    AS origem,
             p.pe_id               AS id_origem,
             p.pe_nome_razaosocial AS nome,
             CASE
             WHEN Len( p.pe_cpf_cnpj ) = 11 THEN 0
             ELSE 1
             end                   pessoa_juridica,
             p.pe_cpf_cnpj         AS documento,
             ( SELECT top 1 pa.pa_valor
               FROM   comum_siga.TB_PESSOA pe
                 JOIN comum_siga.TB_PESSOA_ATRIBUTO pa
                   ON pa.pe_id = pe.pe_id
               WHERE  pa.pa_tipo_atributo = 'DOCUMENTO_RG' AND
                      pe.pe_id = p.pe_id
               ORDER  BY pa.pa_id ASC )          AS rg,
             ( SELECT top 1 pa.pa_valor
               FROM   comum_siga.TB_PESSOA pe
                 JOIN comum_siga.TB_PESSOA_ATRIBUTO pa
                   ON pa.pe_id = pe.pe_id
               WHERE  pa.pa_tipo_atributo = 'DOCUMENTO_ORGAO_EMISSOR' AND
                      pe.pe_id = p.pe_id
               ORDER  BY pa.pa_id ASC )          AS rg_emissor,
             ( SELECT top 1 pa.pa_valor
               FROM   comum_siga.TB_PESSOA pe
                 JOIN comum_siga.TB_PESSOA_ATRIBUTO pa
                   ON pa.pe_id = pe.pe_id
               WHERE  pa.pa_atributo = 'TELEFONE' AND
                      pe.pe_id = p.pe_id
               ORDER  BY pa.pa_id ASC )          AS telefone,
             ( SELECT top 1 pa.pa_valor
               FROM   comum_siga.TB_PESSOA pe
                 JOIN comum_siga.TB_PESSOA_ATRIBUTO pa
                   ON pa.pe_id = pe.pe_id
               WHERE  pa.pa_atributo = 'EMAIL' AND
                      pe.pe_id = p.pe_id
               ORDER  BY pa.pa_id ASC )          AS email,
             p.pa_id               AS pais_id
      FROM   comum_siga.TB_PESSOA p
      UNION
      SELECT 'Efcaz.QuadroAdministrativo' AS origem,
             q.qa_id                      AS id_origem,
             q.qa_nome                    AS nome,
             CASE
             WHEN Upper( q.qa_tipo_documento ) = 'CPF' THEN 0
             ELSE 1
             end                          pessoa_juridica,
             q.qa_documento               AS documento,
             q.qa_doc_rg                  AS rg,
             q.qa_doc_rg_emissor          AS rg_emissor,
             q.qa_telefone                AS telefone,
             q.qa_email                   AS email,
             q.pa_id                      AS pais_id
      FROM   efcaz.TB_QUADRO_ADMINISTRATIVO q
    ) as x
GO
