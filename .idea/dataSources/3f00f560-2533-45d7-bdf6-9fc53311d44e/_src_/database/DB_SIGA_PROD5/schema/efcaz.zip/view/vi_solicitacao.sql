
CREATE VIEW efcaz.vi_solicitacao AS
 SELECT s.so_id AS id,
    s.us_id,
    s.so_tipo_solicitacao AS tipo_solicitacao,
    p.pe_id AS fornecedor_id,
    p.pe_nome_razaosocial AS fornecedor,
    p.pe_cpf_cnpj AS documento,
    p.pa_id AS pais_id,
    s.so_situacao AS situacao,
    s.so_business_key AS business_key,
    s.so_bpm_process_instance_id AS process_instance_id,
    u.us_nome AS solicitante
   FROM efcaz.tb_solicitacao s
     JOIN efcaz_staging.tb_pessoa p ON p.pe_id = s.so_item_id
     JOIN comum.tb_usuario u ON u.us_id = s.us_id
GO
