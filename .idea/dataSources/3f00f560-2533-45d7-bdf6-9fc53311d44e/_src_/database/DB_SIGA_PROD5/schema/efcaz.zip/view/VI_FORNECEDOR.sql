
CREATE VIEW [efcaz].[VI_FORNECEDOR] AS
SELECT ROW_NUMBER() OVER (ORDER BY pe.pe_nome_razaosocial) as ROW_ID,
    peefcaz.pe_id AS FO_PESSOA_ID,
    pe.pa_id AS FO_PESSOA_PAIS_ID,
    pe.pe_logo AS FO_LOGO,
    pe.pe_nome_razaosocial AS FO_RAZAO_SOCIAL,
    pe.pe_nome_fantasia AS FO_FANTASIA,
    pe.pe_cpf_cnpj AS FO_CPF_CNPJ,
    pe.pe_situacao AS FO_SITUACAO,
    CASE
          WHEN pe.pe_ano_cerca IS NOT NULL THEN cast(pe.pe_numero_cerca as varchar(100)) + '/' + cast(pe.pe_ano_cerca as varchar(100))
          ELSE cast(pe.pe_numero_cerca as varchar(100))
    END AS FO_CERCA,
	CASE WHEN pe.pe_numero_cerca IS NULL THEN 0 ELSE 1 END AS CERCA_EMITIDO,
	CASE WHEN peefcaz.PE_EMISSAO_CERCA = 0 THEN 1 WHEN peefcaz.PE_EMISSAO_CERCA = 1 THEN 0 END AS CADASTRO_SIMPLIFICADO,
	pe.pe_impedido AS FO_IMPEDIDO,
    mu.mu_id AS FO_MUNICIPIO_ID,
    mu.uf_id AS FO_UF_ID,
    uf.pa_id AS FO_UF_PAIS_ID,
    nj.nj_id AS FO_NATUREZA_JURIDICA_ID,
    nj.nj_tipo AS FO_TIPO_NATUREZA_JURIDICA	
   FROM efcaz.tb_pessoa_efcaz peefcaz 
     JOIN comum_siga.tb_pessoa pe ON pe.pe_id = peefcaz.pe_id
     LEFT JOIN comum.tb_municipio mu ON pe.mu_id = mu.mu_id
     LEFT JOIN comum.tb_estado uf ON mu.uf_id = uf.uf_id
     JOIN efcaz.tb_natureza_juridica nj ON peefcaz.nj_id = nj.nj_id
GO
