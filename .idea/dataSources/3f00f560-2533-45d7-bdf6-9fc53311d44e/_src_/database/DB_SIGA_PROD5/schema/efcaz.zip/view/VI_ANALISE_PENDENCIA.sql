
CREATE VIEW efcaz.VI_ANALISE_PENDENCIA AS 
 SELECT row_number() OVER (ORDER BY a.an_id, m.mp_id, p.pe_id) AS "ROW",
    a.AN_ID,
    a.AN_RESULTADO,
    a.AN_DATA_ANALISE,
    a.AN_DATA_PUBLICACAO,
    m.MP_ID,
    m.MP_DESCRICAO,
    m.MP_DESCRICAO_ALTERNATIVA,
    m.MP_EXIBIR_ATA,
    p.PE_ID,
    p.PE_DESCRICAO,
    p.PE_PARAMETRO,
        CASE
            WHEN p.mp_id IS NOT NULL THEN
            CASE
                WHEN m.mp_exibir_ata = 1 AND m.mp_descricao_alternativa IS NOT NULL THEN m.mp_descricao_alternativa
                ELSE m.mp_descricao
            END
            ELSE p.pe_descricao
        END AS DESCRICAO_ATA
   FROM efcaz.tb_pendencia p
     LEFT JOIN efcaz.tb_modelo_pendencia m ON m.mp_id = p.mp_id
     LEFT JOIN efcaz.tb_analise_pessoa a ON a.an_id = p.an_id
GO
