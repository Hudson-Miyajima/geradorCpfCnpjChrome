
CREATE PROCEDURE [comum_siga].[SP_MAX_NUMBER_ITEM_MATSER]
            @bool BIT, @CODIGO varchar(20) OUTPUT
            AS
            BEGIN

                SET @CODIGO = (SELECT CAST(MAX(CAST(IMS_CODIGO AS INTEGER)) AS VARCHAR)  FROM comum_siga.TB_ITEM_MATERIAL_SERVICO WHERE PATINDEX('%[^0-9]%', IMS_CODIGO) = 0)
                RETURN @CODIGO;
             END
GO
