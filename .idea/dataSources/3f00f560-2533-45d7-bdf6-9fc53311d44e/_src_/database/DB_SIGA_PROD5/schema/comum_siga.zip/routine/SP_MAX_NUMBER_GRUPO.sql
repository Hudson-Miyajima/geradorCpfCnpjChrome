
CREATE PROCEDURE [comum_siga].[SP_MAX_NUMBER_GRUPO]
            @bool BIT, @CODIGO varchar(20) OUTPUT
            AS
            BEGIN
                SET @CODIGO = (SELECT CAST(MAX(CAST(GR_CODIGO AS INTEGER)) AS VARCHAR)  FROM comum_siga.TB_GRUPO WHERE PATINDEX('%[^0-9]%', GR_CODIGO) = 0)
                RETURN @CODIGO;
            END
GO
