
CREATE VIEW [comum_siga].[VI_ELEMENSUB_MATSERV]
AS 
SELECT es.es_id,
         es.es_codigo,
         es.es_nome,
         isnull(es.es_codigo, '')
         +' '
         +isnull(es.es_nome, '') AS cod_descricao,
         es.es_situacao,
         CASE
           WHEN ( SELECT Count( ms1.ms_id )
                  FROM   comum_siga.TB_MATERIAL_SERVICO ms1
                         join comum_siga.TB_MATSER_SUBELEM mss1
                           ON mss1.ms_id = ms1.ms_id
                         join comum_siga.TB_CONTRATACAO_SUBELEM cs1
                           ON cs1.ns_id = mss1.ns_id
                         join comum_siga.TB_ELEMENTO_SUBELEMEN es1
                           ON es1.es_id = cs1.es_id
                  WHERE  ms1.ms_tipo = 'MATERIAL' AND
                         es1.es_id = es.es_id )
                > 0 THEN 1
           ELSE 0
         END          AS material,
         CASE
           WHEN ( SELECT Count( ms2.ms_id )
                  FROM   comum_siga.TB_MATERIAL_SERVICO ms2
                         join comum_siga.TB_MATSER_SUBELEM mss2
                           ON mss2.ms_id = ms2.ms_id
                         join comum_siga.TB_CONTRATACAO_SUBELEM cs2
                           ON cs2.ns_id = mss2.ns_id
                         join comum_siga.TB_ELEMENTO_SUBELEMEN es2
                           ON es2.es_id = cs2.es_id
                  WHERE  ms2.ms_tipo = 'SERVICO' AND
                         es2.es_id = es.es_id )
                > 0 THEN 1
           ELSE 0
         END          AS servico
  FROM   comum_siga.TB_ELEMENTO_SUBELEMEN es
GO
DECLARE @sn NVARCHAR(30)
SET @sn = schema_name()
EXECUTE sp_addextendedproperty N'MS_Description', N'Visão de uso interno do módulo', N'SCHEMA', @sn, N'VIEW',
                               N'VI_ELEMENSUB_MATSERV'
GO
