
CREATE PROCEDURE [comum_siga].[SP_MAX_NUMBER_CLASSE]
            @id Bigint, @str VARCHAR(20), @CODIGO varchar(20) OUTPUT
            AS
            BEGIN

                SET @CODIGO = (SELECT MAX(CL_CODIGO)  FROM comum_siga.TB_CLASSE WHERE
                (PATINDEX(CONCAT(@str,'[0-9]'), CL_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9]'), CL_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9]'), CL_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9]'), CL_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9][0-9]'), CL_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9][0-9][0-9]'), CL_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9][0-9][0-9][0-9]'), CL_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'), CL_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'), CL_CODIGO) = 1 OR
                PATINDEX(CONCAT(@str,'[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'), CL_CODIGO) = 1) AND
                GR_ID = @id)
                RETURN @CODIGO;
            END
GO
